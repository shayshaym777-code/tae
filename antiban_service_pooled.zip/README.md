# Anti-Ban Service (Pooled Devices)
Supports shared device pool for ALL clients. If a device_id isn't provided by the app, the service auto-picks the best device from the pool.

## Device Pool Admin
- Add to pool:  POST /pool/add    { "device_id": "<ID>" }
- Remove:       POST /pool/remove { "device_id": "<ID>" }
- List:         GET  /pool/list

## Sending Flow
Client -> /check (no device_id) -> service picks device -> ALLOW with device_id -> app sends using that device -> /ack
