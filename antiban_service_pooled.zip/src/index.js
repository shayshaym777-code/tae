import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import bodyParser from 'body-parser';
import { createClient } from 'ioredis';
import dotenv from 'dotenv';
import crypto from 'crypto';

dotenv.config();
const app = express();
app.use(helmet());
app.use(bodyParser.json({ limit: '1mb' }));
app.use(morgan('tiny'));

const PORT = process.env.PORT || 3000;
const redis = new createClient(process.env.REDIS_URL || 'redis://127.0.0.1:6379');

// --- helpers ---
function ym(dt = new Date()) { const y = dt.getUTCFullYear(); const m = String(dt.getUTCMonth()+1).padStart(2,'0'); return `${y}${m}`; }
function ymd(dt = new Date()) { const y = dt.getUTCFullYear(); const m = String(dt.getUTCMonth()+1).padStart(2,'0'); const d = String(dt.getUTCDate()).padStart(2,'0'); return `${y}${m}${d}`; }
function minuteKey(dt = new Date()) { const y = dt.getUTCFullYear(); const m = String(dt.getUTCMonth()+1).padStart(2,'0'); const d = String(dt.getUTCDate()).padStart(2,'0'); const hh=String(dt.getUTCHours()).padStart(2,'0'); const mm=String(dt.getUTCMinutes()).padStart(2,'0'); return `${y}${m}${d}${hh}${mm}`; }
function randInt(min, max){ return Math.floor(Math.random()*(max-min+1))+min; }
function normalizeText(t){ return (t||'').replace(/\s+/g,' ').trim(); }
function sha1(s){ return crypto.createHash('sha1').update(s).digest('hex'); }

// --- config ---
const DEFAULT_MONTHLY_QUOTA = parseInt(process.env.DEFAULT_MONTHLY_QUOTA || '200', 10);
const DEVICE_RATE_PER_MIN = parseInt(process.env.DEVICE_RATE_PER_MIN || '20', 10);
const USER_RATE_PER_MIN = parseInt(process.env.USER_RATE_PER_MIN || '60', 10);
const DEFER_MIN_SECONDS = parseInt(process.env.DEFER_MIN_SECONDS || '10', 10);
const DEFER_MAX_SECONDS = parseInt(process.env.DEFER_MAX_SECONDS || '45', 10);
const WARMUP_SCHEDULE = (process.env.WARMUP_SCHEDULE || '20,40,80,120,160').split(',').map(x=>parseInt(x.trim(),10)).filter(Boolean);
const BANNED_KEYWORDS = (process.env.BANNED_KEYWORDS || '').toLowerCase().split(',').map(s=>s.trim()).filter(Boolean);
const MAX_DUPLICATE_TEXT_PER_HOUR = parseInt(process.env.MAX_DUPLICATE_TEXT_PER_HOUR || '50', 10);
const MIN_HEALTH_FOR_SEND = parseInt(process.env.MIN_HEALTH_FOR_SEND || '40', 10);

// --- quota ---
async function getUserMonthlyQuota(userId){ const v = await redis.get(`plan:user:${userId}:quota`); return v?parseInt(v,10):DEFAULT_MONTHLY_QUOTA; }
async function quotaStatus(userId){
  const key = `quota:${userId}:${ym()}`;
  const used = parseInt((await redis.get(key)) || '0', 10);
  const limit = await getUserMonthlyQuota(userId);
  return { used, limit, exceeded: used >= limit };
}
async function incrQuotaOnAck(userId){
  const key = `quota:${userId}:${ym()}`;
  const n = await redis.incr(key);
  await redis.expire(key, 60*60*24*40);
  return n;
}

// --- rate limiting ---
async function rateHot(deviceId, userId){
  const minKey = minuteKey();
  const userKey = `rl:user:${userId}:${minKey}`;
  const u = await redis.incr(userKey);
  await redis.expire(userKey, 120);
  let hotUser = u > USER_RATE_PER_MIN;

  let hotDev = false;
  if (deviceId) {
    const devKey = `rl:device:${deviceId}:${minKey}`;
    const d = await redis.incr(devKey);
    await redis.expire(devKey, 120);
    hotDev = d > DEVICE_RATE_PER_MIN;
  }
  return { hot: hotUser || hotDev };
}

// --- warmup ---
async function warmupHit(deviceId){
  const dayKey = `warmup:device:${deviceId}:day`;
  let day = parseInt((await redis.get(dayKey)) || '1', 10);
  if (day < 1) day = 1;
  if (day > WARMUP_SCHEDULE.length) day = WARMUP_SCHEDULE.length;
  const today = ymd();
  const cntKey = `wu:device:${deviceId}:${today}`;
  const c = await redis.incr(cntKey);
  await redis.expire(cntKey, 60*60*24*2);
  const limit = WARMUP_SCHEDULE[day-1];
  return { hit: c > limit, count: c, limit, day };
}

// --- content ---
async function contentOk(userId, text){
  const t = normalizeText(text);
  if (t.length < 3) return { ok: false, reason: 'empty_text' };
  const low = t.toLowerCase();
  for (const kw of BANNED_KEYWORDS){ if (kw && low.includes(kw)) return { ok:false, reason:'banned_keyword' }; }
  const h = sha1(low);
  const hourKey = `dup:${userId}:${h}:${ymd()}:${new Date().getUTCHours()}`;
  const c = await redis.incr(hourKey);
  await redis.expire(hourKey, 60*60*2);
  if (c > MAX_DUPLICATE_TEXT_PER_HOUR) return { ok:false, reason:'too_many_duplicates' };
  const uniqueChars = new Set(low.replace(/\s/g,'')).size;
  if (uniqueChars < 8) return { ok:false, reason:'low_entropy' };
  return { ok:true };
}

// --- health ---
async function bumpHealth(deviceId, delta){
  const key = `health:device:${deviceId}`;
  let v = parseInt((await redis.get(key)) || '80', 10);
  v = Math.max(0, Math.min(100, v + delta));
  await redis.set(key, v);
  return v;
}
async function getHealth(deviceId){
  const v = await redis.get(`health:device:${deviceId}`);
  return v?parseInt(v,10):80;
}

// --- pool selection ---
async function pickBestDeviceFromPool(){
  // devices are kept in a Redis set/list: devices:pool
  const ids = await redis.smembers('devices:pool');
  if (!ids || ids.length === 0) return null;
  // rank by health desc, then random jitter
  const scored = [];
  for (const id of ids){
    const h = await getHealth(id);
    if (h < MIN_HEALTH_FOR_SEND) continue;
    const jitter = Math.random();
    scored.push({ id, score: h + jitter });
  }
  scored.sort((a,b)=>b.score-a.score);
  return scored.length?scored[0].id:null;
}

// --- API ---
app.get('/health', async (req,res)=>{
  try { await redis.ping(); res.json({ok:true}); } catch(e){ res.status(500).json({ok:false, error:e.message}); }
});

// Admin endpoints to manage the shared pool
app.post('/pool/add', async (req,res)=>{
  const { device_id } = req.body || {};
  if (!device_id) return res.status(400).json({error:'missing device_id'});
  await redis.sadd('devices:pool', String(device_id));
  res.json({ok:true});
});
app.post('/pool/remove', async (req,res)=>{
  const { device_id } = req.body || {};
  if (!device_id) return res.status(400).json({error:'missing device_id'});
  await redis.srem('devices:pool', String(device_id));
  res.json({ok:true});
});
app.get('/pool/list', async (req,res)=>{
  const ids = await redis.smembers('devices:pool');
  const detailed = [];
  for (const id of ids){
    detailed.push({ id, health: await getHealth(id) });
  }
  res.json({ok:true, devices:detailed});
});

// Main decision: now supports pooled devices (device_id optional)
app.post('/check', async (req,res)=>{
  try {
    const { user_id, device_id, text } = req.body || {};
    if (!user_id) return res.status(400).json({ error: 'missing user_id' });

    // 1) quota
    const q = await quotaStatus(user_id);
    if (q.exceeded) return res.json({ decision:'REJECT', reason:'quota', used:q.used, limit:q.limit });

    // 2) content
    const c = await contentOk(user_id, text || '');
    if (!c.ok) return res.json({ decision:'REJECT', reason:c.reason });

    // 3) select device (if not provided)
    let chosen = device_id;
    if (!chosen){
      chosen = await pickBestDeviceFromPool();
      if (!chosen) return res.json({ decision:'DEFER', reason:'no_device_available', delay: randInt(15,60) });
    }

    // 4) rate
    const r = await rateHot(chosen, user_id);
    if (r.hot) return res.json({ decision:'DEFER', reason:'rate', delay: randInt(10,45) });

    // 5) warmup
    const w = await warmupHit(chosen);
    if (w.hit) return res.json({ decision:'DEFER', reason:'warmup', delay: randInt(20,60), warmupDay:w.day, limit:w.limit });

    return res.json({ decision:'ALLOW', device_id: String(chosen) });
  } catch(e){
    console.error(e);
    res.status(500).json({ error:'server_error' });
  }
});

// ack
app.post('/ack', async (req,res)=>{
  try {
    const { user_id, device_id, status } = req.body || {};
    if (!user_id || !device_id || !status) return res.status(400).json({ error:'missing fields' });
    if (status === 'delivered' || status === 'sent'){ await incrQuotaOnAck(user_id); await bumpHealth(device_id, +1); }
    else if (status === 'failed'){ await bumpHealth(device_id, -2); }
    else if (status === 'blocked' || status === 'reported'){ await bumpHealth(device_id, -10); }
    res.json({ ok:true });
  } catch(e){
    console.error(e);
    res.status(500).json({ ok:false, error:'server_error' });
  }
});

app.listen(PORT, ()=> console.log('Anti-Ban (pooled) on :'+PORT));
