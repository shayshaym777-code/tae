<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('devices')) {
            Schema::table('devices', function (Blueprint $table) {
                if (!Schema::hasColumn('devices','phone_number')) {
                    $table->string('phone_number')->nullable();
                }
                if (!Schema::hasColumn('devices','warmup_day')) {
                    $table->unsignedInteger('warmup_day')->default(1);
                }
                if (!Schema::hasColumn('devices','health_score')) {
                    $table->unsignedInteger('health_score')->default(80);
                }
                if (!Schema::hasColumn('devices','is_admin_managed')) {
                    $table->boolean('is_admin_managed')->default(true);
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('devices')) {
            Schema::table('devices', function (Blueprint $table) {
                if (Schema::hasColumn('devices','phone_number')) {
                    $table->dropColumn('phone_number');
                }
                if (Schema::hasColumn('devices','warmup_day')) {
                    $table->dropColumn('warmup_day');
                }
                if (Schema::hasColumn('devices','health_score')) {
                    $table->dropColumn('health_score');
                }
                if (Schema::hasColumn('devices','is_admin_managed')) {
                    $table->dropColumn('is_admin_managed');
                }
            });
        }
    }
};
