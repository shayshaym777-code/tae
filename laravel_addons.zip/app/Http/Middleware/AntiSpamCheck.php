<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Http;

class AntiSpamCheck
{
    public function handle($request, Closure $next)
    {
        // Bypass for admins if needed:
        if (auth()->check() && method_exists(auth()->user(),'isAdmin') && auth()->user()->isAdmin()) {
            return $next($request);
        }

        $payload = [
            'user_id'     => optional($request->user())->id,
            'device_id'   => $request->input('device_id'),
            'text'        => $request->input('text'),
            'template_id' => $request->input('template_id'),
            'meta'        => [ 'ip' => $request->ip(), 'ts' => now()->toIso8601String() ],
        ];

        $url = config('antispam.url', env('ANTISPAM_URL', 'http://127.0.0.1:8088')).'/check';
        $timeout = (int)config('antispam.timeout', env('ANTISPAM_TIMEOUT_MS', 1500));
        $resp = Http::timeout(max(1, $timeout/1000))->post($url, $payload);

        if ($resp->failed()) {
            return response()->json(['error' => 'Antispam unavailable'], 503);
        }

        $decision = $resp->json('decision', 'ALLOW');

        if ($decision === 'REJECT') {
            return response()->json([
                'error' => $resp->json('reason', 'Rejected by policy'),
                'code'  => 'ANTISPAM_REJECT'
            ], 422);
        }

        if ($decision === 'DEFER') {
            $delay = (int)$resp->json('delay', rand(10,45));
            // Dispatch your normal job with a delay + jitter
            if (class_exists('\App\Jobs\SendMessageJob')) {
                \App\Jobs\SendMessageJob::dispatch($request->all())->delay(now()->addSeconds($delay));
                return response()->json(['status' => 'deferred', 'delay' => $delay], 202);
            }
            // Fallback: just sleep-ish response (not ideal for production)
            return response()->json(['status' => 'deferred', 'delay' => $delay], 202);
        }

        return $next($request); // ALLOW
    }
}
