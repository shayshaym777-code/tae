<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ResetMonthlyUsage extends Command
{
    protected $signature = 'antispam:reset-usage {--dry-run}';
    protected $description = 'Creates a new monthly period rows in message_usage (or resets counts).';

    public function handle()
    {
        $today = now()->startOfMonth()->toDateString();
        $users = DB::table('users')->select('id')->pluck('id');
        foreach ($users as $uid) {
            $exists = DB::table('message_usage')->where('user_id', $uid)->where('period_start', $today)->exists();
            if (!$exists) {
                if (!$this->option('dry-run')) {
                    DB::table('message_usage')->insert([
                        'user_id' => $uid,
                        'period_start' => $today,
                        'sent_count' => 0,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
                $this->info("initialized usage row for user {$uid}");
            }
        }
        $this->info('done.');
        return self::SUCCESS;
    }
}
