<?php

return [
    'url'     => env('ANTISPAM_URL', 'http://127.0.0.1:8088'),
    'timeout' => env('ANTISPAM_TIMEOUT_MS', 1500), // milliseconds
];
