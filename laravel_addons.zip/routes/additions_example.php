<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MessageController;

// Protect device management to admins only
Route::middleware(['auth','can:devices.manage'])->group(function(){
    Route::resource('devices', \App\Http\Controllers\DeviceController::class);
});

// Client send routes protected by antispam
Route::middleware(['auth','can:devices.use','antispam'])->group(function(){
    Route::post('/messages/send', [MessageController::class, 'send']);
    Route::post('/messages/bulk', [MessageController::class, 'bulkSend']);
});
