{{-- Show Devices menu only to admins/managers --}}
@can('devices.manage')
  <li class="nav-item">
    <a href="{{ route('devices.index') }}" class="nav-link">Devices</a>
  </li>
@endcan
