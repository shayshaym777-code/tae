# Laravel Addons for Arrocy Anti-Spam

## Install
1) Copy `config/antispam.php` to your Laravel `config/` and add to `config/app.php` if needed.
2) Copy `app/Http/Middleware/AntiSpamCheck.php` and register alias in `app/Http/Kernel.php`:
```php
protected $routeMiddleware = [
  // ...
  'antispam' => \App\Http\Middleware\AntiSpamCheck::class,
];
```
3) Copy migrations in `database/migrations/` and run:
```
php artisan migrate
```
4) Optionally add console command by registering it in `app/Console/Kernel.php`:
```php
protected function schedule(Schedule $schedule) {
  $schedule->command('antispam:reset-usage')->monthlyOn(1, '03:00');
}
```
5) Wrap your send routes with `antispam` middleware and hide Devices menu from clients.

## ENV
```
ANTISPAM_URL=http://127.0.0.1:8088
ANTISPAM_TIMEOUT_MS=1500
```
